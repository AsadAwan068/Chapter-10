package com.example.chapter10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        WebView webView = findViewById(R.id.webview1);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        Bundle b= getIntent().getExtras();
        switch(b.getInt("website")){
            case 0:{
                webView.loadUrl("https://facebook.com");
                webView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url){
                        // do your handling codes here, which url is the requested url
                        // probably you need to open that url rather than redirect:
                        view.loadUrl(url);
                        return false; // then it is not handled by default action
                    }
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        // do your stuff here
                        super.onPageFinished(view, url);
                        webView.loadUrl("javascript: var x=document.getElementById('m_login_email').value='user123';");
                        webView.loadUrl("javascript: var y=document.getElementById('m_login_password').value='password123';");


                    }
                });
                break;
            }
            case 1:{
                webView.loadUrl("https://www.google.com/maps/@32.46608775788683,74.51402883432716,17z");
                webView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url){
                        // do your handling codes here, which url is the requested url
                        // probably you need to open that url rather than redirect:
                        view.loadUrl(url);
                        return false; // then it is not handled by default action
                    }

                });
                break;
            }
        }
    }
}